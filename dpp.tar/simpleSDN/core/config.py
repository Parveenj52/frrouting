import os
import pathlib
from typing import Any, Dict

import tomli
from pydantic import BaseSettings


def get_app_version() -> str:
    """
    Gets the current version specified in the pyproject.toml
    file by searching through parent directories until the
    file is found.
    """
    current_dir = pathlib.Path(__file__).resolve().parent
    while current_dir != pathlib.Path("/"):
        toml_file_path = current_dir / "pyproject.toml"
        if toml_file_path.exists():
            with open(toml_file_path, mode="rb") as config:
                toml_file = tomli.load(config)
                version = toml_file["tool"]["poetry"]["version"]
            return version
        current_dir = current_dir.parent

    raise FileNotFoundError("pyproject.toml file not found in any parent directory.")


class AppSettings(BaseSettings):
    """
    Application constant settings for the microservice.
    """

    DEBUG: bool = os.getenv("APP_DEBUG")
    DOCS_URL: str = "/docs"
    ROOT_PATH: str = ""
    OPENAPI_URL: str = "/openapi.json"
    REDOC_URL: str = "/redoc"
    APP_TITLE: str = "DOMAIN PROXY PLUGIN - OSM"
    APP_VERSION: str = get_app_version()
    APP_CODE: str = "DPP"
    APP_ORIGIN_NAME = "domain proxy plugin - osm"
    APP_API_PREFIX: str = "/api/dpp/osm"
    APP_DESCRIPTION: str = (
        """Endpoint definitions for the DOMAIN PROXY PLUGIN - Open Source Mano (OSM)."""
    )
    APP_ALLOWED_HOSTS: list[str] = ["*"]
    APP_LOG_LEVEL: str = os.getenv("APP_LOG_LEVEL")
    APP_LOG_FORMAT: str = (
        "<green>{time:DD:MM:YYYY-HH:mm:ss}</green> | {level} | <white>{message}</white>"
    )

    SSL: str = os.getenv("SSL", "true")
    K8S_NAMESPACE: str = os.getenv("K8S_NAMESPACE")
    print("K8S_NAMESPACE is: " + K8S_NAMESPACE)
    OSM_USERNAME: str = os.getenv("OSM_USERNAME", "admin")
    OSM_PASSWORD: str = os.getenv("OSM_PASSWORD", "admin")
    OSM_PROJECT: str = os.getenv("OSM_PROJECT", "admin")
    OSM_VIM_ACCOUNT: str = os.getenv("IDO_VIM_ACCOUNT", "62d4c185-5281-49d6-9c7f-8235ebf63f5d")

    DOMAIN_NAME: str = os.getenv("DOMAIN_NAME", "Generic")

    HOSTS: dict = {
        "dps": {
            "host": os.getenv("DOMAIN_PROXY_HOST", "127.0.0.1"),
            "port": os.getenv("DOMAIN_PROXY_PORT", "8000"),
            "ssl_port": os.getenv("DOMAIN_PROXY_SEC_PORT", "443"),
            "shortname": "DPS",
            "longname": "DOMAIN PROXY SERVICE",
        },
        "k8s": {
            "host": os.getenv("K8S_CLUSTER_HOST", "127.0.0.1"),
            "port": os.getenv("K8S_CLUSTER_PORT", "8450"),
            "shortname": "K8S",
            "longname": "KUBERNETES",
        },
        "osm": {
            "host": os.getenv("OSM_HOST", "10.43.57.158"),
            "port": os.getenv("OSM_PORT", "9999"),
            "shortname": "OSM",
            "longname": "OSM",
        },
    }

    WORKFLOWS: dict = {
        "service": "OBTAINING DATA FOR SERVICE",
        "capabilities": "PROCESSING CAPABILITIES",
        "osm": "OSM QUERY",
    }

    EVENTS: dict = {
        "unavailable": "UNABLE TO REACH HOST",
        "error": "PROCESSING ERROR FROM HOST",
        "success": "PROCESSING SUCCESS FROM HOST",
        "srv_status": "RETRIEVING STATUS FOR SERVICE",
        "capabilities": "RETRIEVING CAPABILITIES",
        "processing": "CONVERTING JSON",
    }

    ENDPOINT_MESSAGES: dict = {
        "failure": "endpoint error",
        "success": "request accepted",
        "capabilities": "capabilities received",
        "err_notfound": "not found",
    }

    @property
    def fastapi_kwargs(self) -> Dict[str, Any]:
        return {
            "debug": self.DEBUG,
            "docs_url": self.DOCS_URL,
            "root_path": self.ROOT_PATH,
            "openapi_url": self.OPENAPI_URL,
            "redoc_url": self.REDOC_URL,
            "title": self.APP_TITLE,
            "version": self.APP_VERSION,
            "description": self.APP_DESCRIPTION,
        }


settings = AppSettings()
