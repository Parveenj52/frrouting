from typing import Any, List

from models.hardware import DomainHardware, HardwareResources
from models.ido_capabilities import IDOCapabilities
from models.node_info import NodeInfo, NodeResources
from models.network_service_info import NetworkServiceInfo, NetworkServiceResources
from models.tasks import SimpleTask, TasksDomain, TasksResources

from .config import settings

qos_mapping = {
    "background": "background",
    "default": "default",
    "high": "high",
    "critical": "critical",
    "low": "background",
    "medium": "default",
}


def convert_memory_to_mb(memory_value: str) -> float:
    """
    Convert memory values across different values.

    Args:
        memory_value (str): The memory value with the unit.

    Returns:
        memory (float): The memory value converted to MB.

    Raises:
        ValueError: If memory units are not recognized.
    """
    if memory_value.endswith("Ki"):  # Kibibyte
        memory = float(memory_value[:-2]) * 0.001024
    elif memory_value.endswith("Mi"):  # Mebibyte
        memory = float(memory_value[:-2]) * 1.04858
    elif memory_value.endswith("M"):  # Megabytes
        memory = float(memory_value[:-1])
    else:
        raise ValueError(f"Unknown memory capacity type - {memory_value}")

    return memory


def get_qos_level(qos_name: str) -> str:
    """
    Map the QoS name sent from the IDO to any of the available levels. If the name
    is not found, use "default".

    Args:
        qos_name (str): The QoS name sent from the IDO.

    Returns:
        (str): The QoS level.
    """
    return qos_mapping.get(qos_name, "default")


def __get_qos_resources(network_service_resources: NetworkServiceResources) -> tuple[float, float]:
    """
    Extracts and converts QoS resource requirements from a network services's configuration.

    Args:
        network service (dict): A dictionary containing the network service specifications.

    Returns:
        tuple[int, float]: A tuple containing the number of CPU cores (int)
                           and memory in megabytes (float).
    """

    cpu_cores = network_service_resources.cpu
    memory = convert_memory_to_mb(network_service_resources.memory)

    return cpu_cores, memory


def __simple_task(
    network_service: NetworkServiceInfo, node_resources: NodeResources
) -> dict[str, Any]:
    """
    Constructs a simple task (service) dictionary for a given ns, assigning
    resources based on QoS requirements.

    Args:
        network services (dict): The network service data containing task name, type, and QoS requirements.
        node_resources (dict): The node's resource information, used to compute CPU and
                               link resource requirements.

    Returns:
        dict[str, Any]: A dictionary representing the task configuration with assigned
                        CPU cores, memory, and computed FLOPS.
    """

    task = SimpleTask(
        network_service_name=network_service.name,
        version="v1",
        network_service_type="GENERIC",
        resource_requirements=[],
    )

    for req in network_service.network_service_requirements:
        qos_name = req.qos
        network_service_resources = req.network_service_resources

        cpu_cores, memory = __get_qos_resources(network_service_resources)
        qos_level = get_qos_level(qos_name)

        task_resource = TasksResources(
            qos_level=qos_level,
            cpu_cores=cpu_cores,
            memory_mb=memory,
            storage_mb=0,
            cpu_flops=__calculate_cpu_flops(cpu_cores, node_resources),
            gpu_flops=0,
            gpu_memory_mb=0.0,
            egress_network_bandwidth_gbps=0,
            ingress_network_bandwidth_gbps=0.0,
        )

        task.resource_requirements.append(task_resource)

    return task


def __calculate_cpu_flops(cpu_cores: int, node_resources: dict) -> int:
    """
    Calculates the CPU floating-point operations per second (FLOPS) based on node resources.
    As described at https://en.wikipedia.org/wiki/Floating_point_operations_per_second

    Args:
        cpu_cores (int): The number of cores.
        node_resources (dict): The node's resource information.

    Returns:
        int: The calculated FLOPS for the CPU based on the given resources.
    """
    cpu_hertz = int(node_resources.cpu_hertz)
    sockets = 1
    fp_cycles = int(node_resources.fp_cycles)

    flops = sockets * cpu_cores * cpu_hertz * fp_cycles / 1000000

    return flops


def aggregate_node_resources(nodes: List[NodeInfo]) -> HardwareResources:
    """
    Calculates the aggregated total resources for an entire IDO.

    Args:
        nodes (List[NodeInfo]): A list of all available nodes.

    Returns:
        total_resources (HardwareResources): An object with the aggregated total resources.
    """
    total_cpu_cores = 0
    total_memory_mb = 0.0
    total_cpu_flops = 0

    for node in nodes:
        node_resources = node.node_resources
        total_cpu_cores += node_resources.cpu_cores
        total_memory_mb += convert_memory_to_mb(node_resources.memory)
        total_cpu_flops += __calculate_cpu_flops(
            node_resources.cpu_cores, node_resources
        )

    total_resources = HardwareResources(
        total_cpu_cores=total_cpu_cores,
        total_memory_mb=total_memory_mb,
        total_cpu_flops=total_cpu_flops,
    )

    return total_resources


def convert_resources(input_data: IDOCapabilities) -> dict[str, Any]:
    """
    Converts input data into a structured resource dictionary for domain tasks,
    aggregating QoS resources and node configurations.

    Args:
        input_data (dict): Input data including network_service requirements and node resources.

    Returns:
        dict[str, Any]: A dictionary with converted domain simple information.
    """

    total_resources = aggregate_node_resources(input_data.nodes)

    domain_hardware = DomainHardware(
        domain_name=settings.DOMAIN_NAME,
        hardware_resources=total_resources,
    )

    tasks_domain = TasksDomain(domain_name=settings.DOMAIN_NAME, tasks=[])

    node_resources = input_data.nodes[0].node_resources

    for network_service in input_data.network_services:
        task = __simple_task(network_service, node_resources)

        tasks_domain.tasks.append(task)

    updated = input_data.updated

    return domain_hardware, tasks_domain, updated
