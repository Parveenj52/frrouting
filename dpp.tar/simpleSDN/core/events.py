import asyncio
from statistics import mean

import aiohttp
from fastapi.encoders import jsonable_encoder
from typing import Callable, List, Dict
import re
from starlette.background import BackgroundTask
from models.ido_capabilities import IDOCapabilities

from .config import settings
from .dict_manipulation import convert_resources, create_ido_capabilities
from .exceptions import HostResponseError
from .httprequests import DPSRequestRouter, K8SRequestRouter, OSMRequestRouter
from .log import log_error, log_payload_check, log_processing
from loguru import logger
from .redisclient import redis_client


HOSTS = getattr(settings, "HOSTS")

def start_app() -> Callable:
    """
    App Controller that runs tasks when starting the application.
    """
    log_processing(
            workflow=settings.WORKFLOWS["redis"],
            message=settings.EVENTS["redis"],
            value="before connection establishment",
        )

    @logger.catch
    async def start_app() -> None:
        cache = await redis_client.establish_connection()
        log_processing(
            workflow=settings.WORKFLOWS["redis"],
            message=settings.EVENTS["redis"],
            value="before health check",
        )
        asyncio.create_task(redis_client.health_check_task(cache))

    return start_app


def stop_app() -> Callable:
    """
    App Controller that runs tasks when stopping the application.
    """

    @logger.catch
    async def stop_app() -> None:

        redis_client.redis_close()

    return stop_app


class BaseEvents(object):
    """
    Base class for event streaming.
    """

    def __init__(self) -> None:
        self.dps_host = HOSTS.get("dps", {}).get("longname")
        self.k8s_host = HOSTS.get("k8s", {}).get("longname")
        self.osm_host = HOSTS.get("osm", {}).get("longname")
        self.event_messages = settings.EVENTS
        self.dps = DPSRequestRouter()
        self.k8s = K8SRequestRouter()
        self.osm = OSMRequestRouter()


class EventHandlers(BaseEvents):
    """
    Class for event handlers that extends BaseEvents with methods that are each
    responsible for conducting a single event stream.
    """

    def __init__(self) -> None:
        super().__init__()

    async def eventhandler_convert_resources(self, workflow: str, data: dict) -> None:
        """
        Handles the conversion of resource data and relays it to the event handler.

        :param workflow: the description of the relevant workflow
        :param data: the data payload being sent
        :returns: None
        """
        log_processing(
                workflow=workflow,
                message="Before convert resources",
                value=data,
            )
        domain_hardware, tasks_domain, updated = convert_resources(data)

        if "nodes" in updated:
            print(domain_hardware)

            hardware = dict(jsonable_encoder(domain_hardware))
            log_processing(
                workflow=workflow,
                message="Before relay_data",
                value=hardware,
            )
            await self.eventhandler_relay_data(
                #workflow=workflow, data=hardware, func="hardware"
                workflow=workflow, service_name="hardware", data=hardware
            )

        if "network_services" in updated:
            print(tasks_domain)

            tasks = dict(jsonable_encoder(tasks_domain))
            log_processing(
                workflow=workflow,
                message="Before relay_data",
                value=tasks,
            )
            await self.eventhandler_relay_data(
                #workflow=workflow, data=tasks, func="tasks"
                workflow=workflow, service_name="tasks", data=tasks
            )

    async def eventhandler_obtain_service_status(
        self, workflow: str, service_name: str
    ) -> dict:
        """
        Event Handler that retrieves service status from the K8s MANO Cluster for
        a given service name.

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "{"ACK"{"message": "all good"}"]
        """
        try:
            response_service: list = await self.k8s.send_k8s_service_status_request(
                workflow, service_name
            )

            if response_service[0] == "200":
                message: str = self.event_messages["success"]
                log_processing(
                    workflow=workflow,
                    message=f"{message}: {self.k8s_host}",
                    value=response_service[1],
                )

                return response_service[1]
            else:
                message: str = self.event_messages["error"]
                log_error(
                    workflow=workflow,
                    message=f"{message}: {self.k8s_host}",
                    value=response_service[1],
                )
        except aiohttp.client_exceptions.ClientConnectorError as err:
            message: str = self.event_messages["unavailable"]
            log_error(
                workflow=workflow, message=f"{message}: {self.k8s_host}", value=err
            )

    async def eventhandler_obtain_task_capabilities(
        self, workflow: str
    ) -> dict:
        """
        Event Handler that retrieves task capabilities from OSM.

        :param workflow: the description of the relevant workflow
        :returns: e.g ["200", "{"ACK"{"message": "all good"}"]
        """
        
        try:
            # httpaio response is a list of two elements: [status, data]
            response_service: dict = await self.osm.send_osm_nsds_request(
                workflow=settings.WORKFLOWS["osm"], grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
            )

            if response_service[0] == "200":
                message: str = self.event_messages["success"]
                log_processing(
                    workflow=workflow,
                    message=f"{message}: {self.osm_host}",
                    value=response_service[1],
                )

                return response_service[1]
            else:
                message: str = self.event_messages["error"]
                log_error(
                    workflow=workflow,
                    message=f"{message}: {self.k8s_host}",
                    value=response_service[1],
                )
        except aiohttp.client_exceptions.ClientConnectorError as err:
            message: str = self.event_messages["unavailable"]
            log_error(
                workflow=workflow, message=f"{message}: {self.k8s_host}", value=err
            )

    async def eventhandler_relay_data(
        self, workflow: str, service_name: str, data: dict
    ) -> None:
        """
        Event Handler that relays data back to the Domain Proxy Service.

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service the data relates to
        :param data: the data payload being sent
        :returns: None
        """
        try:
            if service_name == "hardware":
                response_data: list = (
                    await self.dps.post_dps_service_relay_infrastructure(
                        workflow=workflow,
                        data=data,
                    )
                )
            elif service_name == "tasks":
                response_data: list = await self.dps.post_dps_service_relay_tasks(
                    workflow=workflow,
                    data=data,
                )
            else:
                raise ValueError(f"Service Name '{service_name}' not recognised.")
            
            
            # response_data: list = await self.dps.post_dps_service_relay_data_request(
            #     workflow=workflow, service_name=service_name, data=data
            # )

            if response_data[0] == "200":
                message: str = self.event_messages["success"]
                log_processing(
                    workflow=workflow,
                    message=f"{message}: {self.dps_host}",
                    value=response_data[1],
                )
            else:
                message: str = self.event_messages["error"]
                log_error(
                    workflow=workflow,
                    message=f"{message}: {self.dps_host}",
                    value=response_data[1],
                )
        except aiohttp.client_exceptions.ClientConnectorError as err:
            message: str = self.event_messages["unavailable"]
            log_error(
                workflow=workflow, message=f"{message}: {self.dps_host}", value=err
            )

    async def extract_tasks_from_OSM_NSDs(self, data: List[Dict]) -> List[Dict[str, str]]:
        """
        Extracts 'id', 'description', and any key-value pairs from the description field
        for each NSD item in the input list.

        Args:
            data (List[Dict]): A list of NSD dictionaries.

        Returns:
            List[Dict[str, str]]: A list of dictionaries with extracted fields.
        """
        results = []

        for item in data:
            entry = {
                'id': item.get('_id', ''),
                'name': item.get('name', ''),
                'description': item.get('description', ''),
                'revision': item.get('revision', '')
            }

            # Extract key-value pairs from the beginning of the description
            #kv_matches = re.findall(r'(\w+)=([^;]+);?', entry['description'])
            #for key, value in kv_matches:
            #    entry[key] = value

            # Extract key-value pairs from _admin.userDefinedData if present
            admin_data = item.get('_admin', {})
            user_defined = admin_data.get('userDefinedData', {})
            if isinstance(user_defined, dict):
                for key, value in user_defined.items():
                    entry[key] = value
                    
            results.append(entry)

        return results


class EventRunners(BaseEvents):
    """
    Class that extends BaseEvents with methods to execute event handlers.
    """

    def __init__(self) -> None:
        super().__init__()
        self.events = EventHandlers()

    async def process_capabilities(self, ido_cap) -> None:
        log_processing(
            workflow=settings.WORKFLOWS["capabilities"],
            message=settings.EVENTS["processing"],
            value="capabilites are converted",
        )

        if not ido_cap.nodes:
            log_error(
                workflow=settings.WORKFLOWS["capabilities"],
                message=settings.EVENTS["empty"],
                value="No NODE resources were provided",
            )
            return

        if not ido_cap.network_services:
            log_error(
                workflow=settings.WORKFLOWS["capabilities"],
                message=settings.EVENTS["empty"],
                value="No NETWORK SERVICE resources were provided",
            )
            return
        await self.events.eventhandler_convert_resources(
            workflow=settings.WORKFLOWS["capabilities"], data=ido_cap
        )


    async def retrieve_service_status(self, service_name: str) -> None:
        """
        Event Runner that obtains a service status for a service and returns it
        back to the Domain Proxy Service.

        :returns: None
        """
        log_processing(
            workflow=settings.WORKFLOWS["service"],
            message=settings.EVENTS["srv_status"],
            value=service_name,
        )

        try:
            service_status = await self.events.eventhandler_obtain_service_status(
                workflow=settings.WORKFLOWS["service"], service_name=service_name
            )

            if service_status:
                data = service_status["data"]
                data_avg = mean(data)

                try:
                    await self.events.eventhandler_relay_data(
                        workflow=settings.WORKFLOWS["service"],
                        service_name=service_name,
                        data=data_avg,
                    )
                except HostResponseError as err:
                    message: str = self.event_messages["error"]
                    log_error(
                        workflow=settings.WORKFLOWS["service"],
                        message=f"{message}: {self.dps_host}",
                        value=str(err),
                    )
        except HostResponseError as err:
            message: str = self.event_messages["error"]
            log_error(
                workflow=settings.WORKFLOWS["service"],
                message=f"{message}: {self.k8s_host}",
                value=str(err),
            )

    async def retrieve_capabilities(self) -> None:
        """
        Event Runner that obtains the IDO capabilities and returns them
        back to the Domain Proxy Service.

        :returns: None
        """
        log_processing(
            workflow=settings.WORKFLOWS["capabilities"],
            message=settings.EVENTS["capabilities"],
            value="retrieving capabilities",
        )

        try:
            task_data = await self.events.eventhandler_obtain_task_capabilities(
                workflow=settings.WORKFLOWS["capabilities"]
            )

            if task_data:
                #data = task_data["data"]
                #data_avg = mean(data)
                tasks = await self.events.extract_tasks_from_OSM_NSDs(task_data)
                #log_payload_check(workflow=settings.WORKFLOWS["osm"], message="PAYLOAD", value=tasks)
                ido_capabilities = create_ido_capabilities(tasks)
                await self.process_capabilities(ido_capabilities)
                log_payload_check(workflow=settings.WORKFLOWS["osm"], message="PAYLOAD", value=ido_capabilities)
                # try:
                #     await self.events.eventhandler_relay_data(
                #         workflow=settings.WORKFLOWS["service"],
                #         service_name="service_name",
                #         data=tasks,
                #     )
                # except HostResponseError as err:
                #     message: str = self.event_messages["error"]
                #     log_error(
                #         workflow=settings.WORKFLOWS["service"],
                #         message=f"{message}: {self.osm_host}",
                #         value=str(err),
                #     )
        except HostResponseError as err:
            message: str = self.event_messages["error"]
            log_error(
                workflow=settings.WORKFLOWS["service"],
                message=f"{message}: {self.osm_host}",
                value=str(err),
            )



