class EndpointError(Exception):
    """
    A base exception class for all exceptions.
    """

    pass


class ProcessingError(EndpointError, RuntimeError):
    """
    Raised when processing operations are halted.
    """

    def __init__(self, msg):
        self.msg = msg


class HostUnavailableError(EndpointError):
    """
    Raised when an external host is unavailable or uncontactable.
    """

    def __init__(self, msg):
        self.msg = msg


class HostResponseError(EndpointError):
    """
    Raised when a host returns an unexpected error response.
    """

    def __init__(self, msg):
        self.msg = msg
