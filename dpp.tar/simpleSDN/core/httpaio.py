import socket

import aiohttp
import yaml

from .log import log_url_check


class APIHTTPAsyncIORequestHandler:
    """
    HTTP controller for sending messages across the network in an async fashion.
    """

    def __init__(
        self, url: str, payload=None, token=None, params=None, form_data=None
    ) -> None:
        self.url = url
        self.payload = payload
        self.params = params
        self.form_data = form_data
        self.token = token
        self.headers_token = {"token": self.token}
        self.headers_form = {"content-type": "application/x-www-form-urlencoded"}
        self.conn = aiohttp.TCPConnector(family=socket.AF_INET, ssl=False)
        self.timeout = aiohttp.ClientTimeout(total=200)

    async def send_get_request(self, session) -> list:
        """
        Sends GET requests.
        """
        async with session.get(self.url) as resp:
            response_status = str(resp.status)
            response_data = await resp.json()
            return [response_status, response_data]

    async def send_get_request_with_token(self, session) -> list:
        """
        Sends GET requests with tokens.
        """

        headers = {
            "Authorization": f"Bearer {self.token}"
        }

        async with session.get(self.url, headers=headers) as resp:
            response_status = str(resp.status)

        #async with session.get(self.url, headers=self.headers_token) as resp:
        #    response_status = str(resp.status)
            
            content_type = resp.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                response_data = await resp.json()
            elif 'application/yaml' in content_type:
                response_text = await resp.text()
                response_data = yaml.safe_load(response_text)
            else:
                raise aiohttp.client_exceptions.ContentTypeError(
                    message=f"Unexpected content type: {content_type}",
                    url=str(resp.url)
                )
            return [response_status, response_data]

    async def send_post_json_request(self, session) -> list:
        """
        Sends POST requests with json payloads.
        """
        async with session.post(self.url, json=self.payload) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                response_data = await resp.json()
            return [response_status, response_data]
        
    async def send_post_json_request_with_token(self, session) -> list:
        """
        Sends POST requests with json payloads.
        """

        headers = {
            "Authorization": f"Bearer {self.token}"
        }
        
        log_url_check("In post_json_request_with _token", message="data", value=self.payload)

        async with session.post(self.url, headers=headers, json=self.payload) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                

                content_type = resp.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                response_data = await resp.json()
            elif 'application/yaml' in content_type:
                response_text = await resp.text()
                response_data = yaml.safe_load(response_text)
            else:
                raise aiohttp.client_exceptions.ContentTypeError(
                    message=f"Unexpected content type: {content_type}",
                    url=str(resp.url)
                )
            #response_data = await resp.json()
            return [response_status, response_data]

    async def send_post_data_request(self, session) -> list:
        """
        Sends POST requests with data payloads.
        """
        async with session.post(
            self.url, data=self.payload, headers=self.headers_form
        ) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                

                content_type = resp.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                response_data = await resp.json()
            elif 'application/yaml' in content_type:
                response_text = await resp.text()
                response_data = yaml.safe_load(response_text)
            else:
                raise aiohttp.client_exceptions.ContentTypeError(
                    message=f"Unexpected content type: {content_type}",
                    url=str(resp.url)
                )
            #response_data = await resp.json()
            return [response_status, response_data]

    async def send_post_params_request(self, session) -> list:
        """
        Sends POST requests with parameters.
        """
        async with session.post(
            self.url,
            params=self.params,
            headers=self.headers_form,
        ) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                response_data = await resp.json()
            return [response_status, response_data]

    async def send_post_params_formdata_request(self, session) -> list:
        """
        Sends POST requests with parameters and form data.
        """
        async with session.post(
            self.url,
            params=self.params,
            data=self.form_data,
            headers=self.headers_form,
        ) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                response_data = await resp.json()
            return [response_status, response_data]

    async def send_patch_request(self, session) -> list:
        """
        Sends PATCH requests with tokens.
        """
        async with session.patch(
            self.url, json=self.payload, headers=self.headers_token
        ) as resp:
            response_status = str(resp.status)

            if response_status == "500":
                response_data = await resp.text()
            else:
                response_data = await resp.json()
            return [response_status, response_data]

    async def send_delete_request_with_token(self, session) -> list:
        """
        Sends DELETE requests with token.
        """

        headers = {
            "Authorization": f"Bearer {self.token}"
        }

        async with session.delete(self.url, headers=headers) as resp:
            response_status = str(resp.status)
            if response_status == "500":
                response_data = await resp.text()
            else:
                content_type = resp.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                response_data = await resp.json()
            elif 'application/yaml' in content_type:
                response_text = await resp.text()
                response_data = yaml.safe_load(response_text)
            else:
                raise aiohttp.client_exceptions.ContentTypeError(
                    message=f"Unexpected content type: {content_type}",
                    url=str(resp.url)
                )
            return [response_status, response_data]
    
    async def send_delete_request(self, session) -> list:
        """
        Sends DELETE requests.
        """
        async with session.delete(self.url) as resp:
            response_status = str(resp.status)

            if response_status == "204":
                response_data = None
            else:
                response_data = await resp.json()
            return [response_status, response_data]

    async def request_director(self, http_method) -> list:
        """
        Directs the incoming request to the correct send method.

        :param http_method: the http method to envoke
        """
        async with aiohttp.ClientSession(
            connector=self.conn, timeout=self.timeout
        ) as session:
            if http_method == "post_json":
                task = self.send_post_json_request(session)
                result = await task
            elif http_method == "post_json_token":
                task = self.send_post_json_request_with_token(session)
                result = await task
            elif http_method == "post_data":
                task = self.send_post_data_request(session)
                result = await task
            elif http_method == "post_param_formdata":
                task = self.send_post_params_formdata_request(session)
                result = await task
            elif http_method == "post_param":
                task = self.send_post_params_request(session)
                result = await task
            elif http_method == "get":
                task = self.send_get_request(session)
                result = await task
            elif http_method == "get_token":
                task = self.send_get_request_with_token(session)
                result = await task
            elif http_method == "patch":
                task = self.send_patch_request(session)
                result = await task
            elif http_method == "delete_token":
                task = self.send_delete_request_with_token(session)
                result = await task
            else:
                task = self.send_delete_request(session)
                result = await task
            return result
