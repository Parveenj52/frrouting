from fastapi.encoders import jsonable_encoder


from .config import settings
from .httpaio import APIHTTPAsyncIORequestHandler
from .log import log_payload_check, log_url_check

API_SETTINGS = getattr(settings, "HOSTS")


class BaseRequestRouter(object):
    """
    Base class for routing requests to external services.
    """

    def __init__(self) -> None:
        self.dps_host = API_SETTINGS.get("dps", {}).get("host")
        self.dps_port = API_SETTINGS.get("dps", {}).get("port")
        self.dps_ssl_port = API_SETTINGS.get("dps", {}).get("ssl_port")
        self.k8s_host = API_SETTINGS.get("k8s", {}).get("host")
        self.k8s_port = API_SETTINGS.get("k8s", {}).get("port")
        self.k8s_namespace = settings.K8S_NAMESPACE
        self.osm_host = API_SETTINGS.get("osm", {}).get("host")
        self.osm_port = API_SETTINGS.get("osm", {}).get("port")


    def __get_dps_base_url(self) -> str:
        """
        Private Base url for the Domain Proxy Service.
        """
        if settings.SSL == "false":
            return f"http://{self.dps_host}:{self.dps_port}/api/dps/services"
        else:
            return f"https://{self.dps_host}:{self.dps_ssl_port}/api/dps/services"

    def __get_k8s_base_url(self) -> str:
        """
        Private Base url for the K8s MANO Cluster.
        """

        if settings.SSL == "false":
            return f"http://{self.k8s_host}/api/v1"
        else:
            return f"https://{self.k8s_host}:{self.k8s_port}/api/v1"

    def get_dps_service_relay_data_url(self) -> str:
        """
        Resource url for the Domain Proxy Service Data Relay endpoint.
        """
        return f"{self.__get_dps_base_url()}/relay-data"

    def get_k8s_services_url(self) -> str:
        """
        Resource url for the K8s MANO Services endpoint.
        """
        print("k8s base url is: " + self.__get_k8s_base_url())
        return f"{self.__get_k8s_base_url()}/namespaces/{self.k8s_namespace.lower()}/services/"

    def get_osm_base_url(self) -> str:
        """
        Private Base url for OSM.
        """

        if settings.SSL == "false":
            return f"http://{self.osm_host}:{self.osm_port}/osm"
        else:
            return f"https://{self.osm_host}:{self.osm_port}/osm"


class DPSRequestRouter(BaseRequestRouter):
    """
    Controller that extends BaseRequestRouter with methods for
    requests to the Domain Proxy Service.
    """

    def __init__(self) -> None:
        super().__init__()

    async def post_dps_service_relay_data_request(
        self, workflow: str, service_name: str, data: dict
    ) -> list:
        """
        Handles POST requests to the DPS to send data.

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service the data relates to
        :param data: the performance data payload
        :returns: e.g ["200", "{"ACK"{"message": "all good"}"]
        """
        api_url: str = self.get_dps_service_relay_data_url()
        payload = {"service_name": service_name, "service_payload": {"average": data}}

        log_url_check(workflow, message="URL", value=api_url)
        log_payload_check(workflow, message="PAYLOAD", value=payload)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, payload=payload)
        response: list = await httpio.request_director(http_method="post_json")

        return response


class K8SRequestRouter(BaseRequestRouter):
    """
    Controller that extends BaseRequestRouter with methods for
    requests to the K8s MANO Cluster.
    """

    def __init__(self) -> None:
        super().__init__()

    async def send_k8s_service_status_request(
        self, workflow: str, service_name: str
    ) -> list:
        """
        Handles POST requests with the K8S Cluster to obtain a status for
        a given service name.

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "{"ACK"{"message": "all good"}"]
        """
        api_url: str = f"{self.get_k8s_services_url()}{service_name}/status"

        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, payload=None)
        response: list = await httpio.request_director(http_method="post_json")

        return response

class OSMRequestRouter(BaseRequestRouter):
    """
    Controller that extends BaseRequestRouter with methods for
    requests to OSM.
    """

    def __init__(self) -> None:
        super().__init__()

        self.token=""
    
    async def send_osm_token_request(
        self, workflow: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles POST requests with OSM to obtain an auth token

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """
        api_url: str = f"{self.get_osm_base_url()}/admin/v1/tokens"
        #payload: dict[str, str] = {"grant_type": grant_type, "username": osm_username, "password": osm_password}
        payload = f"grant_type={grant_type}&username={osm_username}&password={osm_password}"

        log_url_check(workflow, message="URL", value=api_url)
        log_url_check(workflow, message="Payload", value=payload)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, payload=payload)
        response: list = await httpio.request_director(http_method="post_data")

        # Extract the _id from the response
        status_code, data = response
        self.token = data.get('_id')
        log_url_check(workflow, message="Token", value=self.token)

        return response 

    async def send_osm_projects_request(
        self, workflow: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles GET requests with OSM to obtain list of projects

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """

        #Fist get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')
    
        api_url: str = f"{self.get_osm_base_url()}/admin/v1/projects"


        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="get_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="get_token")

        return response 
    
    async def send_osm_nsds_request(
        self, workflow: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles GET requests with OSM to obtain list of nsds

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """

        #First get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')
    
        api_url: str = f"{self.get_osm_base_url()}/nsd/v1/ns_descriptors"


        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="get_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="get_token")

        return response

    async def send_osm_nsd_request(
            self, workflow: str, nsd_id: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles GET requests with OSM to obtain list of nsds

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """

        #Fist get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')
    
        api_url: str = f"{self.get_osm_base_url()}/nsd/v1/ns_descriptors/{nsd_id}" # Assuming nsd_id is the ID of the NSD you want to query

        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="get_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="get_token")

        return response 
                
    async def send_osm_ns_instances_request(
        self, workflow: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles GET requests with OSM to obtain list of ns instances

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """

        #Fist get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')
    
        api_url: str = f"{self.get_osm_base_url()}/nslcm/v1/ns_instances"


        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="get_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="get_token")

        return response   
      
    async def send_osm_ns_instance_request(
            self, workflow: str, ns_id: str, grant_type: str, osm_username: str, osm_password: str
    ) -> list:
        """
        Handles GET requests with OSM to obtain ns instance
        :param nsd_id: the ID of the NSD you want to query
        :param grant_type: the grant type for OSM authentication
        :param osm_username: the OSM username
        :param osm_password: the OSM password

        :param workflow: the description of the relevant workflow
        :param service_name: the name of the service
        :returns: e.g ["200", "_id: token"\n...]
        """

        #First get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')
    
        api_url: str = f"{self.get_osm_base_url()}/nslcm/v1/ns_instances/{ns_id}" # Assuming ns_id is the ID of the NS you want to query

        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="get_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="get_token")

        return response        
       
    async def send_osm_new_ns_instance_request(
    self, workflow: str, ns_instance, grant_type: str, osm_username: str, osm_password: str
    ):
        """
        Sends a request to create a new network service instance in OSM.
        :param workflow: the description of the relevant workflow
        :param ns_instance: the NetworkServiceInstance object to be created
        :param grant_type: the type of grant for OSM authentication
        :param osm_username: the username for OSM authentication
        :param osm_password: the password for OSM authentication
        :returns: a dictionary containing the response data
        """
        
        #First get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

        api_url: str = f"{self.get_osm_base_url()}/nslcm/v1/ns_instances_content"

        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token, payload=jsonable_encoder(ns_instance))
        response: list = await httpio.request_director(http_method="post_json_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token, payload=jsonable_encoder(ns_instance))
            response: list = await httpio.request_director(http_method="post_json_token")

        return response 
    
    async def send_osm_terminate_ns_instance_request(
            self, workflow: str, nsi_id, grant_type: str, osm_username: str, osm_password: str
    ):
        """
        Sends a request to create a new network service instance in OSM.
        :param workflow: the description of the relevant workflow
        :param ns_instance: the NetworkServiceInstance object to be created
        :param grant_type: the type of grant for OSM authentication
        :param osm_username: the username for OSM authentication
        :param osm_password: the password for OSM authentication
        :returns: a dictionary containing the response data
        """

        #First get token if none
        if self.token == "":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

        api_url: str = f"{self.get_osm_base_url()}/nslcm/v1/ns_instances_content/{nsi_id}"

        log_url_check(workflow, message="URL", value=api_url)

        httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
        response: list = await httpio.request_director(http_method="delete_token")

        #if response is 401, get a new token and try again
        status_code, data = response
        if status_code == "401":
            response= await self.send_osm_token_request(settings.WORKFLOWS["osm"], grant_type, osm_username, osm_password)
            status_code, data = response
            self.token = data.get('_id')

            log_url_check(workflow, message="URL", value=api_url)

            httpio = APIHTTPAsyncIORequestHandler(url=api_url, token=self.token)
            response: list = await httpio.request_director(http_method="delete_token")

        return response 