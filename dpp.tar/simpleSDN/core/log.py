import sys

from loguru import logger

from .config import settings

logger.remove(0)
logger.add(
    sys.stderr,
    level=settings.APP_LOG_LEVEL or "DEBUG",
    format=settings.APP_LOG_FORMAT,
    colorize=True,
    enqueue=True,
)


class APILogMessage(object):
    """
    Represents an API Log message to be used with the logger.
    """

    def __init__(self, workflow: str, message: str, value: str) -> None:
        self.workflow = workflow
        self.message = message
        self.value = value

    @classmethod
    def message(cls, workflow=None, message=None, value=None) -> str:
        """Crafts a log message"""
        response = f"{workflow} | {settings.APP_CODE} | {message} -> {value}"

        return response


def log_data_check(task):
    def decorate(func):
        async def _wrapper(*args, **kwargs):
            """
            A wrapper function to add debug data check logging capabilities to func.
            """
            result = await func(*args, **kwargs)

            log_message = APILogMessage.message(
                workflow="DATA CHECK", message=task, value=result
            )
            logger.debug(log_message)

            return result

        return _wrapper

    return decorate


def log_payload_check(workflow: str, message: str, value: dict[str, str]):
    """
    Creates a custom debug log message for checking payloads.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.debug(log_message)


def log_url_check(workflow: str, message: str, value: str):
    """
    Creates a custom debug log message for checking urls.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.debug(log_message)


def log_error(workflow: str, message: str, value: str):
    """
    Creates a custom log message for endpoint failures.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.error(log_message)


def log_processing(workflow: str, message: str, value: str):
    """
    Creates a custom log message for endpoint processing information.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.info(log_message)
    
def db_connection(workflow: str, message: str, value: str):
    """
    Creates a custom log message for the database connection.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.debug(log_message)


def db_error(workflow: str, message: str, value: str):
    """
    Creates a custom log message for database failures.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.error(log_message)


def db_write(workflow: str, message: str, value: str):
    """
    Creates a custom log message for the database connection.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.debug(log_message)


def db_delete(workflow: str, message: str, value: str):
    """
    Creates a custom log message for the database connection.
    """
    log_message = APILogMessage.message(workflow, message, value)
    logger.debug(log_message)

