from typing import Any, List, Dict, Optional

from .config import settings
from models.ido_monitoring import (InfraResources, UtilisationResources, NodeResources, BareMetalResources,
                                   PackageResources, DomainPackageResources)


# Helper to extract bare metal instance data
def extract_metric_value(instance, label, values):
    for entry in values:
        metric = entry["metric"]
        if metric[label] == instance:
            return entry["value"][1]
    return None


def extract_status(status_data):
    """
    Extracts the status from the response.

    Args:
        status_data (dict): The status dictionary from queries_results.

    Returns:
        str: Extracted status.
    """
    if status_data and "data" in status_data and "result" in status_data["data"]:
        results = status_data["data"]["result"]
        if results:
            return results[0]["metric"].get("phase", "Unknown")  # Default to "Unknown" if missing

    return "Unknown"


def convert_baremetal_resources(queries_results: List[dict]) -> dict[str, Any]:
    """
    Converts input data into a structured resource dictionary for domain tasks,
    aggregating QoS resources and node configurations.

    Args:
        input_data (dict): Input data including package requirements and node resources.

    Returns:
        dict[str, Any]: A dictionary with converted domain simple information.
    """
    nodes = []
    label = "instance"
    # create a list of nodes but turn it into a set Collection to keep only the unique values
    unique_nodes = {entry["metric"][label] for metrics in queries_results
                    for metric_type in metrics.values() for entry in metric_type}

    for node in unique_nodes:
        node_data = {"node_name": node}
        for metric in queries_results:
            for metric_type, values in metric.items():
                metric_value = extract_metric_value(node, label, values)
                if metric_value:
                    node_data[metric_type] = float(metric_value)

        noderesources = NodeResources(
            node_name=node_data["node_name"],
            node_cpu_utilisation_percent=node_data["node_cpu_utilisation_percent"],
            node_memory_utilisation_percent=node_data["node_memory_utilisation_percent"],
            node_network_bandwidth=node_data["node_network_bandwidth"]
        )
        nodes.append(noderesources)

    baremetal_resources = BareMetalResources(
        domain_name=settings.DOMAIN_NAME,
        nodes=nodes
    )

    return baremetal_resources


def convert_infra_resources(queries_results: List[dict]) -> InfraResources:
    """
    Converts input data from Thanos/PromQL into a structured resource dictionary for domain resources.

    Args:
        input_data (dict): Input monitoring PromQL data after querying Thanos.

    Returns:
        dict[str, Any]: A dictionary with converted domain resources.
    """

    for result in queries_results:

        if "cpu_util" in result:
            # the format is {'cpu_util' : [{'metric': {}, 'value': [1731603343.113, '5.696522633744808']}]}
            # Convert from string to float
            cpu_usage_percent = float(result['cpu_util'][0]['value'][1])
        if "memory_util" in result:
            memory_usage_percent = float(result['memory_util'][0]['value'][1])
        if "net_iface_bw" in result:
            network_bandwidth = float(result['net_iface_bw'][0]['value'][1])

    util = UtilisationResources(
        cpu_usage_percent=cpu_usage_percent,
        memory_usage_percent=memory_usage_percent,
        network_bandwidth=network_bandwidth)

    infra_resources = InfraResources(
        domain_name=settings.DOMAIN_NAME,
        utilisation=util)

    return infra_resources


def extract_task_latest_value(metric_list: List[Dict[str, Any]]) -> Optional[float]:
    """ Extract the latest numeric value from a list of metric data. """
    if not metric_list:
        return 0.0  # Return default value to avoid None errors
    return float(metric_list[-1]['value'][1])


def extract_task_instance_name(metric_list: List[Dict[str, Any]]) -> Optional[str]:
    """ Extract the pod name from the metric dictionary. """
    if not metric_list:
        return None
    return metric_list[-1]['metric'].get('pod')


def extract_task_status(metric_list: List[Dict[str, Any]]) -> Optional[str]:
    """ Extract the last reported status phase. """
    if not metric_list:
        return None
    return metric_list[-1]['metric'].get('phase')


def get_pod_with_smallest_uptime(metric_list: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Find the pod with the smallest uptime by sorting the metric list by the uptime value.
    Returns the pod metric with the smallest uptime.
    """
    if not metric_list:
        return None
    # Sort the metric list by uptime (ascending order) and return the first (smallest uptime)
    return sorted(metric_list, key=lambda x: float(x['value'][1]))[0]  # Sorting by uptime value


def get_metric_value_for_pod(metric_list: List[Dict[str, Any]], pod_name: str) -> Optional[float]:
    """ Extract the value for a given pod from the list of metrics. """
    for metric in metric_list:
        if metric['metric'].get('pod') == pod_name:
            return float(metric['value'][1])
    return 0.0  # Return default value if the pod name is not found


def convert_task_resources(raw_data: List[Dict[str, Any]]) -> DomainPackageResources:
    """ Convert the raw list of package metrics into a structured DomainPackageResources object. """
    package_resources_list = []

    for package in raw_data:
        metric_data = package.get("metric_data", {})

        # For each package, find the pod with the smallest uptime
        uptime_seconds = metric_data.get("uptime_seconds", [])
        pod_with_smallest_uptime = get_pod_with_smallest_uptime(uptime_seconds)

        if pod_with_smallest_uptime:
            pod_name = extract_task_instance_name([pod_with_smallest_uptime])  # Extract pod name
            # Now extract the corresponding values for this pod from other metrics
            cpu_usage_percent = get_metric_value_for_pod(metric_data.get("cpu_usage_percent", []), pod_name)
            memory_mb = get_metric_value_for_pod(metric_data.get("memory_mb", []), pod_name)
            ingress_network_bandwidth_mbps = get_metric_value_for_pod(metric_data.get("ingress_network_bandwidth_mbps", []),
                                                                      pod_name)
            egress_network_bandwidth_mbps = get_metric_value_for_pod(metric_data.get("egress_network_bandwidth_mbps", []),
                                                                     pod_name)
            status = extract_task_status(metric_data.get("status", []))

            package_resource = PackageResources(
                package_name=package["package_name"],
                deployment_id=package["deployment_id"],
                instance_name=pod_name,
                uptime_seconds=int(extract_task_latest_value([pod_with_smallest_uptime])),  # Using smallest uptime pod
                cpu_usage_percent=cpu_usage_percent,
                memory_mb=memory_mb,
                ingress_network_bandwidth_mbps=ingress_network_bandwidth_mbps,
                egress_network_bandwidth_mbps=egress_network_bandwidth_mbps,
                status=status
            )

            package_resources_list.append(package_resource)

    return DomainPackageResources(domain_name=settings.DOMAIN_NAME, packages=package_resources_list)
