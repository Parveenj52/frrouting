import asyncio
import time
import redis

from .config import settings
from .log import db_connection, db_delete, db_error, db_write

REDIS = getattr(settings, "HOSTS").get("redis")
REDIS_HOST = REDIS["host"]
REDIS_PORT = REDIS["port"]
REDIS_PASSWORD = REDIS["password"]


class RedisClient:
    """
    A client class to manage Redis connections and operations. This class provides
    methods to connect, establish connection, perform health checks, and perform
    basic Redis operations like getting, setting, and deleting data from Redis.
    """

    def __init__(self):
        """
        Initialises the RedisClient with no active connection. Use `establish_connection()`
        to create a Redis connection.
        """
        self.connection = None

    def connect(self):
        """
        Connects to a Redis instance using the settings specified in the configuration.

        Returns:
            redis.Redis: A Redis connection object.

        Raises:
            redis.exceptions.ConnectionError: If unable to connect to Redis.
        """
        redis_connect = redis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            db=0,
            decode_responses=True,
            password=REDIS_PASSWORD,
        )

        redis_connect.ping()
        self.connection = redis_connect

        return redis_connect

    async def establish_connection(self):
        """
        Attempts to establish a persistent connection to Redis, retrying if the connection fails.
        Logs connection and error messages to the system.

        Returns:
            redis.Redis: A Redis connection object once established.
        """
        while True:
            try:
                redis_connect = self.connect()
                db_connection(
                    workflow=settings.WORKFLOWS["redis"],
                    message=settings.EVENTS["redis"],
                    value=redis_connect,
                )
                return redis_connect
            except redis.exceptions.ConnectionError as err:
                message: str = settings.EVENTS["error"]
                db_error(
                    workflow=settings.WORKFLOWS["redis"],
                    message=f"{message}: REDIS",
                    value=str(err),
                )

                time.sleep(10)

    async def redis_ping(self, connection) -> bool:
        """
        Sends a ping command to the Redis server to check if the connection is alive.

        Args:
            connection (redis.Redis): The Redis connection object.

        Returns:
            bool: True if the connection is healthy, False otherwise.
        """
        try:
            connection.ping()
            db_connection(
                workflow=settings.WORKFLOWS["redis"],
                message=settings.EVENTS["ping"],
                value=connection,
            )

            return True
        except redis.exceptions.ConnectionError as err:
            message: str = settings.EVENTS["error"]
            db_error(
                workflow=settings.WORKFLOWS["redis"],
                message=f"{message}: REDIS",
                value=str(err),
            )

            return False

    async def health_check_task(self, connection):
        """
        Periodically checks the health of the Redis connection (every 10 seconds).
        If the connection is unhealthy, attempts to re-establish the connection.

        Args:
            connection (redis.Redis): The Redis connection object.
        """
        while True:
            await asyncio.sleep(10)
            if not await self.redis_ping(connection):
                await self.establish_connection()

    def redis_get(self, key: str):
        """
        Retrieves the value associated with a given key from Redis.

        Args:
            key (str): The key to retrieve the value for.

        Returns:
            str: The value associated with the key, or None if the key does not exist.
        """
        return self.connection.get(key)

    def redis_get_all(self, wildcard="*", fetch_values=False):
        """
        Retrieves all keys matching a given wildcard pattern from Redis.

        Args:
            redis_client (redis.Redis): The Redis client instance.
            pattern (str): The wildcard pattern to match keys (default is '*').
            fetch_values (bool): If True, fetch and return the values for the keys as well.

        Returns:
            list: If fetch_values is False, a list of keys.
            dict: If fetch_values is True, a dictionary with keys and their corresponding values.
        """
        # Get all matching keys
        keys = self.connection.keys(wildcard)

        if not fetch_values:
            # Return only keys
            return keys

        # Fetch values for each key using redis_get
        key_value_pairs = {}
        for key in keys:
            value = self.redis_get(key)
            key_value_pairs[key] = value

        return key_value_pairs

    def redis_set(self, key: str, value: str):
        """
        Sets a key-value pair in Redis.

        Args:
            key (str): The key to set.
            value (str): The value to set for the key.
        """
        self.connection.set(key, value)
        value_set = [key, {"value": value}]
        db_write(
            workflow=settings.WORKFLOWS["redis"],
            message=settings.EVENTS["redis_write"],
            value=value_set,
        )

    def redis_delete(self, key: str) -> bool:
        """
        Deletes a key from Redis.

        Args:
            key (str): The key to delete.

        Returns:
            bool: True if the key was deleted successfully.
        """
        self.connection.delete(key)
        db_delete(
            workflow=settings.WORKFLOWS["redis"],
            message=settings.EVENTS["redis_delete"],
            value=key,
        )

        return True

    def redis_close(self):
        self.connection.close()


redis_client = RedisClient()


async def get_redis_client():
    """
    Returns an instance of the RedisClient class.

    Returns:
        RedisClient: A RedisClient instance for managing Redis connections.
    """
    return redis_client
