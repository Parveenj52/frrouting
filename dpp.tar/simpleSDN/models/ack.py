from models.base import BaseMessage
from pydantic import BaseModel


class ACKResponse(BaseModel):
    """
    API schema for returning an ACK response.
    """

    ACK: BaseMessage
