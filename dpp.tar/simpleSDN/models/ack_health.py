from models.base import BaseMessage
from pydantic import BaseModel


class ACKResponseHealth(BaseModel):
    """
    API schema for returning an ACK Healthcheck response.
    """

    ACK: BaseMessage
