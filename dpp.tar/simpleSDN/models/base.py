from typing import Optional

from core.config import settings
from pydantic import BaseModel


class BaseMessage(BaseModel):
    """
    Base schema for returning a ACK/NACK response.
    """

    origin: str = settings.APP_ORIGIN_NAME
    message: str
    id: Optional[str] | None
