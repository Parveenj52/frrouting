from models.base import BaseMessage


class Fail(BaseMessage):
    """
    Schema for returning a Fail message.
    """

    reason: str
