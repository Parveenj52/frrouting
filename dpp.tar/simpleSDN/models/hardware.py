from typing import List, Optional

from pydantic import BaseModel


class HardwareResources(BaseModel):
    """
    A base model for the hardware resources of a domain.
    """

    total_cpu_cores: int
    total_cpu_flops: int
    total_gpu_flops: Optional[int] = 0
    total_gpu_memory_mb: Optional[float] = 0
    total_memory_mb: float
    total_storage_mb: Optional[float] = 0
    network_bandwidth_gbps: Optional[float] = 0


class DomainHardware(BaseModel):
    """
    The base model for domain's infrastructure.
    """

    domain_name: str
    features: Optional[List[str]] = []
    blacklisted: Optional[List[str]] = []
    hardware_resources: HardwareResources


class NodeResources(BaseModel):
    """
    The base model for a node's infrastructure resources.
    """
    node_total_cpu_cores: int
    node_total_cpu_flops: int
    node_total_gpu_flops: Optional[int] = 0
    node_total_gpu_memory_mb: Optional[float] = 0
    node_total_memory_mb: float
    node_total_storage_mb: Optional[float] = 0
    network_bandwidth_gbps: Optional[float] = 0
