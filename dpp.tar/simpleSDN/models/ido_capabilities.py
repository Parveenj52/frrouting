from typing import List, Literal

from pydantic import BaseModel

from models.node_info import NodeInfo
#from models.package_info import PackageInfo
from models.network_service_info import NetworkServiceInfo


class IDOCapabilities(BaseModel):
    """
    Base schema for the package info.
    """

    nodes: List[NodeInfo]
    network_services: List[NetworkServiceInfo]
    updated: List[Literal["nodes", "network_services"]]
