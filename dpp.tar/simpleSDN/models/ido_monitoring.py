from pydantic import BaseModel
from typing import Optional, List


class NodeResources(BaseModel):
    """
    Base model for the node resources.
    """
    node_name: str
    node_cpu_utilisation_percent: float = 0.0             # Current CPU utilisation percentage of the node.
    node_memory_utilisation_percent: float = 0.0          # Current memory utilisation percentage of the node.
    node_network_bandwidth: float = 0.0                   # Current network bandwidth usage of the node.
    node_disk_utilisation_value: Optional[float]          # Current disk utilisation percentage of the node.
    node_total_cpu_cores: Optional[int]                   # Total CPU cores available on the node.
    node_total_memory_mb: Optional[int]                   # Total memory available on the node in MB.
    node_total_disk_gb: Optional[int]                     # Total disk capacity on the node in GB.
    node_total_BW_gbps: Optional[int]                     # Total bandwidth capacity of the node in Gbps.
    node_used_FLOPS: Optional[int]                        # Currently used FLOPS on the node.
    node_available_FLOPS: Optional[int]                   # Available FLOPS on the node.


class BareMetalResources(BaseModel):
    """
    Base model for the domain/infrastructure info.
    """
    domain_name: str
    nodes: List[NodeResources]


class UtilisationResources(BaseModel):
    """
    Base model for the domain utilisation resources.
    """
    cpu_usage_percent: float = 0.0                  # Percentage of CPU FLOPs currently in use.
    memory_usage_percent: float = 0.0               # Percentage of memory currently in use.
    network_bandwidth: float = 0.0                  # Network bandwidth in bytes
    gpu_usage_percent: Optional[float]              # Percentage of GPU FLOPs currently in use.
    storage_usage_percent: Optional[float]          # Percentage of storage currently in use.
    power_consumption_w: Optional[float]            # Current power consumption in Watts.
    energy_consumption_wh: Optional[float]          # Total energy consumption in Watthours.


class InfraResources(BaseModel):
    """
    Base model for the domain/infrastructure info.
    """
    domain_name: str
    utilisation: UtilisationResources


class PackageResources(BaseModel):
    """
    Base model for the domain utilisation resources.
    """
    package_name: str
    deployment_id: str
    cpu_usage_percent: float = 0.0                  # Percentage of CPU FLOPs currently in use.
    memory_mb: float = 0.0                          # Memory usage in MB.
    egress_network_bandwidth_mbps: float = 0.0      # Percentage of egress network bandwidth currently in use.
    ingress_network_bandwidth_mbps: float = 0.0      # Percentage of network bandwidth currently in use.
    status: str                                     # Status of package (e.g. Running, Failed etc)
    uptime_seconds: int                             # Uptime in seconds
    instance_name: Optional[str]
    storage_mb: Optional[int]
    gpu_usage_percent: Optional[float]              # Percentage of GPU FLOPs currently in use.
    storage_usage_percent: Optional[float]          # Percentage of storage currently in use.
    power_consumption_w: Optional[float]            # Current power consumption in Watts.
    energy_consumption_wh: Optional[float]          # Total energy consumption in Watthours.


class DomainPackageResources(BaseModel):
    """
    Base model for the domain/infrastructure info.
    """
    domain_name: str
    packages: List[PackageResources]
