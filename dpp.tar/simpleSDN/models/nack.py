from models.fail import Fail
from pydantic import BaseModel


class NACKResponse(BaseModel):
    """
    API schema for returning a NACK response.
    """

    NACK: Fail
