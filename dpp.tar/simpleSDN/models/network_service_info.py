from typing import List, Optional

from pydantic import BaseModel


class NetworkServiceResources(BaseModel):
    """
    Base model for the node network services.
    """

    container: str
    cpu: float = 0
    memory: str = "0Ki"
    bandwidth: str = "0Mbps"


class NetworkServiceQoS(BaseModel):
    """
    Base model for the node resources.
    """

    qos: Optional[str] = "default"
    revision: str
    network_service_resources: NetworkServiceResources


class NetworkServiceInfo(BaseModel):
    """
    Base model for the node info.
    """

    name: str
    network_service_requirements: List[NetworkServiceQoS]
