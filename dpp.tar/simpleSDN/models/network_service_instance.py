from pydantic import BaseModel
from core.config import settings



class NetworkServiceInstance(BaseModel):
    """
    Base schema for the package info.
    """

    nsdId: str = ""
    nsDescription: str ="default description"
    vimAccountId: str = settings.OSM_VIM_ACCOUNT
    nsName: str = "default name"
