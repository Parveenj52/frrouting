from typing import Optional

from pydantic import BaseModel


class NodeResources(BaseModel):
    """
    Base model for the node resources.
    """

    cpu_brand: Optional[str] = "generic"
    cpu_arch: Optional[str] = "X86_64"
    fp_cycles: int = 8
    cpu_hertz: int = 0
    cpu_cores: int = 0
    memory: str = "0Ki"


class NodeInfo(BaseModel):
    """
    Base model for the node info.
    """

    name: str
    cluster_id: str
    node_resources: NodeResources
