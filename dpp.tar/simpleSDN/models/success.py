from models.base import BaseMessage


class Success(BaseMessage):
    """
    Schema for returning a Success message.
    """

    message: str
