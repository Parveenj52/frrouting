from typing import Literal, Optional

from pydantic import BaseModel


class TasksResources(BaseModel):
    """
    Schema for defining the resources of a simple task and its QoS.
    """

    qos_level: Literal["background", "default", "high", "critical"]
    cpu_cores: float
    memory_mb: float
    storage_mb: Optional[int] = 0
    cpu_flops: Optional[int] = 0
    gpu_flops: int
    gpu_memory_mb: Optional[float] = 0
    egress_network_bandwidth_gbps: Optional[float] = 0
    ingress_network_bandwidth_gbps: Optional[float] = 0


class SimpleTask(BaseModel):
    """
    Schema for defining a simple task.
    """

    network_service_name: str
    version: str
    network_service_type: Literal["ML", "GENERIC"]
    interoperability_tags: Optional[list[str]]
    blacklisted_tags: Optional[list[str]]
    resource_requirements: list[TasksResources]


class TasksDomain(BaseModel):
    """
    Schema for the IDO Tasks object.
    """

    domain_name: str
    tasks: list[SimpleTask]
