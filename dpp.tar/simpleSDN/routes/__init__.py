from fastapi import APIRouter
from routes import healthchecks, services, resources, admin

router = APIRouter()
router.include_router(services.router, tags=["services"], prefix="/services")
router.include_router(resources.router, tags=["resources"], prefix="/resources")
router.include_router(
    healthchecks.router, tags=["healthchecks"], prefix="/healthchecks"
)
router.include_router(
    admin.router, tags=["admin"], prefix="/admin"
)
