import asyncio
import aiohttp

from typing import Union
from core.config import settings
from fastapi import APIRouter, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from models.ack_health import ACKResponseHealth
from core.log import log_error, log_processing
from core.httprequests import OSMRequestRouter


ENDPOINT_MESSAGES = settings.ENDPOINT_MESSAGES
osm_host = "osm.osm" #HOSTS.get("thanos", {}).get("longname")

osm = OSMRequestRouter()
router = APIRouter()


@router.get(
    path="/tokens",
    summary="Get token",
    description="Returns token",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="admin:get-token",
)
async def get_osm_token() -> JSONResponse:
    """
    Endpoint getting authentication token from OSM admin interface.
    """

    resp_dict = await query_osm()


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to DPS",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm():
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending token request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_token_request(
            workflow=settings.WORKFLOWS["osm"], grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict

@router.get(
    path="/projects",
    summary="Get projects",
    description="Returns projects",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="admin:get-projects",
)
async def get_osm_projects() -> JSONResponse:
    """
    Endpoint getting list of projects from OSM admin interface.
    """
    resp_dict = await query_osm_projects()


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to DPS",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm_projects():
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending projects request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_projects_request(
            workflow=settings.WORKFLOWS["osm"], grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict