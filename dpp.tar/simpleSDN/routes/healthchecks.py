import asyncio

from fastapi import APIRouter, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from models.ack_health import ACKResponseHealth

router = APIRouter()


@router.get(
    path="/readiness",
    summary="Check readiness",
    description="Returns a PONG response",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="healthchecks:list-readiness",
)
async def get_readiness_pong():
    """
    Endpoint for providing a pong response.
    """
    await asyncio.sleep(1)

    success_text = "online"
    ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

    return JSONResponse(
        status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
    )
