import aiohttp
import asyncio
from typing import Union
from core.config import settings
from fastapi import APIRouter, Response, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from models.ack_health import ACKResponseHealth
from core.log import log_error, log_processing
from core.monitoring_dict_manipulation import convert_infra_resources, convert_task_resources
from core.httprequests import ThanosRequestRouter
from core.redisclient import redis_client

ENDPOINT_MESSAGES = settings.ENDPOINT_MESSAGES

net_iface_device = settings.NET_IFACE_DEVICE_NAME
HOSTS = getattr(settings, "HOSTS")
thanos_host = HOSTS.get("thanos", {}).get("longname")
thanos = ThanosRequestRouter()
router = APIRouter()

@router.get(
    path="/infrastructure",
    summary="Provide IDO Infrastructure resources",
    description="Sends the IDO infrastructure resources with or without an averaging window",
    name="monitoring_infrastructure:send",
    status_code=status.HTTP_200_OK,
)
async def get_infrastructure_resources(window: str = "current") -> JSONResponse:
    """
    Endpoint view for retrieving the status of a service.
    """
    # Deduplicate the results by using the hostname label only
    if window == "current":
        memory_util = 'avg (instance:node_memory_utilisation:ratio{hostname!=""} * 100)'
        cpu_util = 'avg (cluster:node_cpu:ratio*100)'
        net_iface_bw = f'(sum (irate(node_network_receive_bytes_total{{device="{net_iface_device}", hostname!=""}}[1m]) \
                        + irate(node_network_transmit_bytes_total{{device="{net_iface_device}", hostname!=""}}[1m])))'
    else:
        memory_util = f'avg (avg_over_time(instance:node_memory_utilisation:ratio{{hostname!=""}}[{window}])*100)'
        cpu_util = f'avg (avg_over_time (cluster:node_cpu:ratio[{window}]) *100)'
        net_iface_bw = f'(sum (irate(node_network_receive_bytes_total{{device="{net_iface_device}", hostname!=""}}[{window}]) \
                        + irate(node_network_transmit_bytes_total{{device="{net_iface_device}", hostname!=""}}[{window}])))'

    thanos_queries = {"cpu_util": cpu_util, "memory_util": memory_util, "net_iface_bw": net_iface_bw}
    print(thanos_queries)
    responses = []

    for query_name in thanos_queries:

        resp_dict = await query_thanos(query_name, thanos_queries)
        responses.append(resp_dict)

    converted_data = convert_infra_resources(responses)

    log_processing(
        workflow=settings.WORKFLOWS["infrastructure"],
        message="Sending to DPS",
        value=jsonable_encoder(converted_data),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(converted_data),
    )

@router.get(
    path="/tasks",
    summary="Provide IDO Task resources",
    description="Sends the IDO task resources with or without an averaging window",
    name="monitoring_infrastructure:send",
    status_code=status.HTTP_200_OK,
)
async def get_task_resources() -> JSONResponse:
    """
    Endpoint view for retrieving the status of a service.
    """

    packages_deployments = redis_client.redis_get_all(wildcard="*", fetch_values=True)
    
    log_processing(
        workflow=settings.WORKFLOWS["redis"],
        message="db contents",
        value=jsonable_encoder(packages_deployments),
    )

    if packages_deployments:
        queries = {
            "cpu_usage_percent": (
                "sum(node_namespace_pod_container:container_cpu_usage_seconds_total:sum_irate"
                "{{pod=~\"{pod}.*\"}}) by (pod)"
            ),
            "memory_mb": (
                "sum(container_memory_working_set_bytes"
                "{{pod=~\"{pod}.*\", container=\"\"}}) "
                "by (pod) / 1024 / 1024"
            ),
            "ingress_network_bandwidth_mbps": (
                "sum(rate(container_network_receive_bytes_total"
                "{{pod=~\"{pod}.*\"}}[2m])) by (pod)"
            ),
            "egress_network_bandwidth_mbps": (
                "sum(rate(container_network_transmit_bytes_total"
                "{{pod=~\"{pod}.*\"}}[2m])) by (pod)"
            ),
            "status": (
                "sum(kube_pod_status_phase"
                "{{pod=~\"{pod}.*\"}} == 1) "
                "by (pod, phase)"
            ),
            "uptime_seconds": (
                "sum(round(time() - kube_pod_created"
                "{{pod=~\"{pod}.*\"}})) by (pod)"
            ),
        }

        thanos_responses = []

        # Query each package individually
        for package_name, deployment_id in packages_deployments.items():
            package_responses = {
                "package_name": package_name,
                "deployment_id": deployment_id,
                "metric_data": {},
            }  # Initialize metric_data as an empty dictionary

            pod_queries = {query_name: query_template.format(pod=package_name) for query_name, query_template in queries.items()}

            for query_name in pod_queries.keys():
                resp_dict = await query_thanos(query_name, pod_queries)  # Query Thanos for this pod
                package_responses["metric_data"][query_name] = resp_dict[query_name]  # Store the result under the query name

            thanos_responses.append(package_responses)

        converted_data = convert_task_resources(thanos_responses)

        log_processing(
            workflow=settings.WORKFLOWS["task"],
            message="Sending to DPS",
            value=jsonable_encoder(converted_data),
        )

        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content=jsonable_encoder(converted_data),
        )
    else:
        return Response(status_code=204)

# @router.get(
#     path="/infrastructure",
#     summary="Get infrastructure",
#     description="Returns infra",
#     response_model=ACKResponseHealth,
#     status_code=status.HTTP_200_OK,
#     name="healthchecks:list-readiness",
# )
# async def get_readiness_pong():
#     """
#     Endpoint for providing a pong response.
#     """
#     await asyncio.sleep(1)

#     success_text = "online"
#     ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

#     return JSONResponse(
#         status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
#     )

# @router.get(
#     path="/tasks",
#     summary="Get tasks",
#     description="Returns tasks",
#     response_model=ACKResponseHealth,
#     status_code=status.HTTP_200_OK,
#     name="healthchecks:list-readiness",
# )
# async def get_readiness_pong():
#     """
#     Endpoint for providing a pong response.
#     """
#     await asyncio.sleep(1)

#     success_text = "online"
#     ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

#     return JSONResponse(
#         status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
#     )
    
async def query_thanos(query_name: str, thanos_queries: dict):
    log_processing(
        workflow=settings.WORKFLOWS["thanos"],
        message=f"Sending data to {thanos_host}",
        value=thanos_queries[query_name]
    )
    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await thanos.post_query_thanos(
            workflow=settings.WORKFLOWS["thanos"], query=thanos_queries[query_name]
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["thanos"],
                message=f"{message}: {thanos_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["thanos"],
                message=f"{message}: {thanos_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["infrastructure"],
            message=f"{message}: {thanos_host}",
            value=err
        )
    #resp_dict = {query_name: response_data[1]['data']['result']}
    resp_dict = {
                    'cpu_util': [
            {
                'value': [1692364800.0, "23.5"]  # [timestamp, cpu usage as string]
            }
        ],
        "memory_util": [
            {
                'value': [1692364800.0, "50.0"]  # [timestamp, memory usage as string]
            }
        ],
        "net_iface_bw": [
            {
                'value': [1692364800.0, "1000.0"]  # [timestamp, network bandwidth as string]
            }
        ]
        }

    return resp_dict