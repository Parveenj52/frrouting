import asyncio
from typing import Union
from core.config import settings
from fastapi import APIRouter, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from models.ack_health import ACKResponseHealth

ENDPOINT_MESSAGES = settings.ENDPOINT_MESSAGES

router = APIRouter()


@router.get(
    path="/infrastructure",
    summary="Get infrastructure",
    description="Returns infra",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="healthchecks:list-readiness",
)
async def get_readiness_pong():
    """
    Endpoint for providing a pong response.
    """
    await asyncio.sleep(1)

    success_text = "online"
    ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

    return JSONResponse(
        status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
    )

@router.get(
    path="/tasks",
    summary="Get tasks",
    description="Returns tasks",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="healthchecks:list-readiness",
)
async def get_readiness_pong():
    """
    Endpoint for providing a pong response.
    """
    await asyncio.sleep(1)

    success_text = "online"
    ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

    return JSONResponse(
        status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
    )