from typing import Union

import aiohttp
import asyncio

from core.config import settings
from core.events import EventRunners
from fastapi import APIRouter, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from models.ack import ACKResponse
from models.ack_health import ACKResponseHealth
from core.log import log_error, log_processing
from core.httprequests import OSMRequestRouter
from models.nack import NACKResponse
from starlette.background import BackgroundTask
from models.ido_capabilities import IDOCapabilities
from models.network_service_instance import NetworkServiceInstance
from models.success import Success


ENDPOINT_MESSAGES = settings.ENDPOINT_MESSAGES

router = APIRouter()
osm = OSMRequestRouter()
osm_host = "osm.osm"


@router.get(
    path="/nsds",
    summary="Get network service descriptors",
    description="Returns network service descriptors from OSM admin interface.",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="services:get-nsds",
)
async def get_osm_nsds() -> JSONResponse:
    """
    Endpoint getting list of NSDs from OSM admin interface.
    """
    resp_dict = await query_osm_nsds()


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to DPS",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm_nsds():
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending nsds request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_nsds_request(
            workflow=settings.WORKFLOWS["osm"], grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict

@router.get(
    path="/nsd/{nsd_id}",
    summary="Get network service descriptor",
    description="Returns a single network service descriptor from OSM admin interface.",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="services:get-nsd",
)
async def get_osm_nsd(nsd_id:str) -> JSONResponse:
    """
    Endpoint getting single NSD from OSM admin interface.
    """
    resp_dict = await query_osm_nsd(nsd_id)


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to DPS",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm_nsd(nsd_id: str):
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending nsd request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_nsd_request(
            settings.WORKFLOWS["osm"], nsd_id, grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
            
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict

@router.get(
    path="/ns_instances",
    summary="Get network service instances",
    description="Returns network service instances from OSM admin interface.",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="services:get-ns-instances",
)
async def get_osm_ns_instances() -> JSONResponse:
    """
    Endpoint getting list of NS Instances from OSM admin interface.
    """
    resp_dict = await query_osm_ns_instances()


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to IDO",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm_ns_instances():
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending ns instances request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_ns_instances_request(
            workflow=settings.WORKFLOWS["osm"], grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict

@router.get(
    path="/ns_instance/{ns_id}",
    summary="Get network service instance",
    description="Returns a single network service instance from OSM admin interface.",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="services:get-ns-instance",
)
async def get_osm_ns_instance(ns_id:str) -> JSONResponse:
    """
    Endpoint getting single NS instance from OSM admin interface.
    """
    resp_dict = await query_osm_ns_instance(ns_id)


    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to DPS",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def query_osm_ns_instance(ns_id: str):
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending ns instance request to osm",
        value=""
    )
    
    response_data = {} # Initialize response_data to an empty dictionary

    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_ns_instance_request(
            settings.WORKFLOWS["osm"], ns_id, grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
            
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data

    return resp_dict

@router.post(
    path="/deploy/{nsd_id}",
    summary="Create new network service instance",
    description="Creates a new network service instance in OSM.",
    name="services:new-ns-instance",
    status_code=status.HTTP_200_OK,
)
async def new_ns_instance(nsd_id: str) -> JSONResponse:
    """
    Endpoint view for creating a new network service instance.
    """

    ns_instance = NetworkServiceInstance(
        nsdId=nsd_id,
        nsDescription="default description",
        vimAccountId=settings.OSM_VIM_ACCOUNT,
        nsName="default name",
    )

    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to OSM",
        value=jsonable_encoder(ns_instance),
    )

    resp_dict = await send_osm_new_ns_instance(ns_instance)

    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to OSM",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def send_osm_new_ns_instance(ns_instance: NetworkServiceInstance):
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending new ns instance request to osm",
        value=""
    )
    response_data = {}  # Initialize response_data to an empty dictionary
    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_new_ns_instance_request(
            settings.WORKFLOWS["osm"], ns_instance, grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data
    return resp_dict

@router.post(
    path="/terminate/{nsi_id}",
    summary="Terminate network service instance",
    description="Terminates a network service instance in OSM.",
    name="services:terminate-ns-instance",
    status_code=status.HTTP_200_OK,
)
async def terminate_ns_instance(nsi_id: str) -> JSONResponse:
    """
    Endpoint view for terminating a network service instance.
    """
    resp_dict = await send_osm_terminate_ns_instance(nsi_id)

    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message="Sending to OSM",
        value=jsonable_encoder(resp_dict),
    )

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(resp_dict),
    )

async def send_osm_terminate_ns_instance(nsi_id: str):
    log_processing(
        workflow=settings.WORKFLOWS["osm"],
        message=f"Sending terminate ns instance request to osm",
        value=""
    )
    response_data = {}  # Initialize response_data to an empty dictionary
    try:
        # httpaio response is a list of two elements: [status, data]
        response_data: dict = await osm.send_osm_terminate_ns_instance_request(
            settings.WORKFLOWS["osm"], nsi_id, grant_type="password", osm_username=settings.OSM_USERNAME, osm_password=settings.OSM_PASSWORD
        )

        if response_data[0] == "200":
            message: str = settings.EVENTS["success"]
            log_processing(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
        else:
            message: str = settings.EVENTS["error"]
            log_error(
                workflow=settings.WORKFLOWS["osm"],
                message=f"{message}: {osm_host}",
                value=response_data[1],
            )
    except aiohttp.client_exceptions.ClientConnectorError as err:
        message: str = settings.EVENTS["unavailable"]
        log_error(
            workflow=settings.WORKFLOWS["osm"],
            message=f"{message}: {osm_host}",
            value=err
        )
    resp_dict = response_data
    return resp_dict

@router.post(
    path="/receive_capabilities",
    summary="advertise IDO capabilities",
    description="Receives the advertised IDO capabilities after an event is triggered",
    name="capabilities:receive",
    status_code=status.HTTP_200_OK,
)
async def receive_capabilities(ido_capabilities: IDOCapabilities) -> JSONResponse:
    """
    Endpoint view for receiving the capabilities of an IDO.
    """

    event = EventRunners()
    task = BackgroundTask(event.process_capabilities, ido_capabilities)

    success_text: str = ENDPOINT_MESSAGES["capabilities"]
    ack_message = Success(message=success_text, id=200)

    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=jsonable_encoder(ack_message),
        background=task,
    )

@router.post(
    path="/{service_name}/status",
    summary="retrieve service status",
    description="Retrieves service status for a given service name.",
    response_model=Union[ACKResponse, NACKResponse],
    name="services:retrieve-status",
    status_code=status.HTTP_202_ACCEPTED,
    responses={400: {"model": NACKResponse}},
)
async def retrieve_service_status(
    service_name: str,
) -> JSONResponse:
    """
    Endpoint view for retrieving the status of a service.
    """
    event = EventRunners()
    task = BackgroundTask(
        event.retrieve_service_status,
        service_name=service_name,
    )

    success_text: str = ENDPOINT_MESSAGES["success"]
    ack_message = ACKResponse(
        ACK={
            "message": success_text,
            "id": service_name,
        }
    )

    return JSONResponse(
        status_code=status.HTTP_202_ACCEPTED,
        content=jsonable_encoder(ack_message),
        background=task,
    )

@router.get(
    path="/check_ido_status",
    summary="Check readiness",
    description="Returns a PONG response",
    response_model=ACKResponseHealth,
    status_code=status.HTTP_200_OK,
    name="services:check-ido-status",
)
async def get_readiness_pong():
    """
    Endpoint for providing a pong response.
    """
    await asyncio.sleep(1)

    success_text = "online"
    ack_message = ACKResponseHealth(ACK={"message": success_text, "id": "200"})

    return JSONResponse(
        status_code=status.HTTP_200_OK, content=jsonable_encoder(ack_message)
    )

@router.get(
    path="/capability_advertisement",
    summary="Request capability responses",
    description="Returns an accept request response",
    response_model=Union[ACKResponse, NACKResponse],
    name="services:capability-advertisement",
    status_code=status.HTTP_202_ACCEPTED,
    responses={400: {"model": NACKResponse}},
)
async def retrieve_capabilities(
) -> JSONResponse:
    """
    Endpoint view for retrieving the status of a service.
    """

    event = EventRunners()
    task = BackgroundTask(
        event.retrieve_capabilities
    )

    success_text: str = ENDPOINT_MESSAGES["success"]
    ack_message = ACKResponse(
        ACK={
            "message": success_text
        }
    )

    return JSONResponse(
        status_code=status.HTTP_202_ACCEPTED,
        content=jsonable_encoder(ack_message),
        background=task,
    )

