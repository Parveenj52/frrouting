from core.config import settings
from fastapi import FastAPI
from routes import router as api_router
from starlette.middleware.cors import CORSMiddleware


def server() -> FastAPI:
    """
    Sets up the application and return an Application instance to Uvicorn.
    """
    application = FastAPI(**settings.fastapi_kwargs)

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.APP_ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    application.include_router(api_router, prefix=settings.APP_API_PREFIX)

    return application


app = server()
