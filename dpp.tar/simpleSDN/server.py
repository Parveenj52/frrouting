from core.config import settings
from fastapi import FastAPI
from routes import router as api_router
from starlette.middleware.cors import CORSMiddleware
from core.events import (
    start_app,
    stop_app,
)


def server() -> FastAPI:
    """
    Sets up the application and return an Application instance to Uvicorn.
    """
    application = FastAPI(**settings.fastapi_kwargs)

    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.APP_ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    application.add_event_handler(
        "startup",
        start_app(),
    )

    application.add_event_handler(
        "shutdown",
        stop_app(),
    )

    application.include_router(api_router, prefix=settings.APP_API_PREFIX)

    return application


app = server()
